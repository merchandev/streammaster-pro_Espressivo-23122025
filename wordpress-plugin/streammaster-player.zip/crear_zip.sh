#!/bin/bash
# Script para empaquetar el plugin
zip -r streammaster-player.zip streammaster-player.php
echo "Plugin comprimido en: streammaster-player.zip"
